public class Derived extends Base {

   public Derived( ) { }
   
   public void f1( ) {
	   System.out.println("Base f1");
   }
   
   public void f2( ) {
	   System.out.println("Derived f2");
   }

   // add necessary function(s) here.

}

