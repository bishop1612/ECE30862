public class Base {

   public Base( ) { 
   }
   
   public void f1( ) {
	   System.out.println("Base f1");
   }
   
   public void f2( ) {
	   System.out.println("Base f2");
   }

   // add necessary function(s) here 


}

