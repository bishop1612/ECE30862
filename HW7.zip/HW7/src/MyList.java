
public abstract class MyList {
	
	public abstract MyList next();
	
	public abstract void printNode();

}
