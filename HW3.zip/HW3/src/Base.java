public class Base {

   public Base( ) { }
   
   public void f1( ) {
	   System.out.println("Base f1");
   }
   
   public void f1(int i) {
	   System.out.println("Base f1(int)");
   }
   
 


  // Add any needed method(s) here.

}

