
public class Test {

	public static void main(String[] args) {
		long i = 1;
		long j = 2;
		new IntegerArithmetic(i,j);
		System.out.println(IntegerArithmetic.add());
		System.out.println(IntegerArithmetic.subtract());
		System.out.println(IntegerArithmetic.divide());
		System.out.println(IntegerArithmetic.multiply());
		// TODO Auto-generated method stub

	}

}
